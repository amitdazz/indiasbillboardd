import { getStore } from '@netlify/blobs';

const MIN = 149;
const MAX = 2499;
const WINDOW = 24 * 60 * 60 * 1000;
const STORE_NAME = 'daily-indian-billboard';
const KEY = 'state';
const NOTIFY_EMAIL = 'dazzamit98@gmail.com';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, x-admin-password',
  'Access-Control-Allow-Methods': 'GET,POST,PATCH,OPTIONS'
};

function response(status, body) {
  return new Response(JSON.stringify(body), { status, headers });
}
function cleanState(s) {
  return {
    bids: Array.isArray(s?.bids) ? s.bids : [],
    current: s?.current || null,
    scheduledNext: s?.scheduledNext || null,
    startAt: s?.startAt || new Date().toISOString(),
    endAt: s?.endAt || new Date(Date.now() + WINDOW).toISOString(),
    raised: Number(s?.raised || 0)
  };
}
async function store() { return getStore({ name: STORE_NAME, consistency: 'strong' }); }
async function loadState() {
  const s = await store();
  const saved = await s.get(KEY, { type: 'json' });
  if (saved) return cleanState(saved);
  const fresh = cleanState({});
  await s.setJSON(KEY, fresh);
  return fresh;
}
async function saveState(state) {
  await (await store()).setJSON(KEY, state);
  return state;
}
async function rollWindow(state) {
  if (Date.now() < new Date(state.endAt).getTime()) return state;
  if (state.scheduledNext) {
    const next = state.scheduledNext;
    state.current = next;
    state.scheduledNext = null;
    state.bids = [];
    state.raised = 0;
    state.startAt = new Date().toISOString();
    state.endAt = new Date(Date.now() + WINDOW).toISOString();
    return saveState(state);
  }
  // No scheduled brand: start a clean 24-hour window.
  state.current = null;
  state.bids = [];
  state.raised = 0;
  state.startAt = new Date().toISOString();
  state.endAt = new Date(Date.now() + WINDOW).toISOString();
  return saveState(state);
}
function adminOk(request) {
  const expected = process.env.ADMIN_PASSWORD;
  return !!expected && request.headers.get('x-admin-password') === expected;
}
async function sendBidEmail(bid, state) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!key || !from) return { sent: false, reason: 'Email variables not configured' };
  const html = `
  <h2>New Billboard Bid</h2>
  <p><b>Brand:</b> ${esc(bid.brandName)}</p>
  <p><b>Bid:</b> ₹${Number(bid.bidAmount).toLocaleString('en-IN')}</p>
  <p><b>Website:</b> ${esc(bid.websiteUrl)}</p>
  <p><b>Tagline:</b> ${esc(bid.tagline)}</p>
  <p><b>Contact:</b> ${esc(bid.contact)}</p>
  <p><b>Time:</b> ${new Date(bid.timestamp).toLocaleString('en-IN')}</p>
  <p><b>Current leading bid:</b> ₹${Number(state.current?.bidAmount || bid.bidAmount).toLocaleString('en-IN')}</p>`;
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [NOTIFY_EMAIL], subject: `New Billboard Bid — ${bid.brandName} ₹${bid.bidAmount}`, html })
  });
  if (!r.ok) return { sent: false, reason: await r.text() };
  return { sent: true };
}
function esc(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

export default async (request) => {
  try {
    if (request.method === 'OPTIONS') return new Response('', { status: 204, headers });
    let state = await loadState();
    state = await rollWindow(state);

    if (request.method === 'GET') {
      return response(200, state);
    }

    if (request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const brandName = String(body.brandName || '').trim();
      const websiteUrl = String(body.websiteUrl || '').trim() || '#';
      const tagline = String(body.tagline || '').trim() || 'Featured on The Daily Indian Billboard.';
      const contact = String(body.contact || '').trim();
      const bidAmount = Number(body.bidAmount);
      if (brandName.length < 2) return response(400, { error: 'Enter a valid brand name.' });
      if (websiteUrl !== '#' && !/^https?:\/\//i.test(websiteUrl)) return response(400, { error: 'Website must start with http:// or https://.' });
      if (!contact) return response(400, { error: 'Enter your UPI / email.' });
      if (!Number.isInteger(bidAmount) || bidAmount < MIN || bidAmount > MAX) return response(400, { error: `Bid must be between ₹${MIN} and ₹${MAX}.` });
      const highest = Math.max(0, ...state.bids.map(b => Number(b.bidAmount) || 0), Number(state.current?.bidAmount) || 0);
      if (bidAmount <= highest) return response(409, { error: `Your bid must be higher than ₹${highest}.` });

      const initials = (brandName.match(/[A-Za-z0-9]+/g) || [brandName]).slice(0,2).map(x=>x[0]).join('').toUpperCase();
      const logoUrl = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="24" fill="#FFE500"/><text x="64" y="78" text-anchor="middle" font-family="Arial" font-size="42" font-weight="900" fill="#080808">${esc(initials)}</text></svg>`);
      const bid = {
        brandName, websiteUrl, tagline, bidAmount, contact,
        logoUrl, creativeUrl: typeof body.creativeUrl === 'string' && body.creativeUrl.length < 1000000 ? body.creativeUrl : '',
        handle: '@' + brandName.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g,'').slice(0,15),
        timestamp: new Date().toISOString()
      };
      state.bids.push(bid);
      state.bids.sort((a,b) => Number(b.bidAmount) - Number(a.bidAmount));
      state.current = state.bids[0];
      state.raised = state.bids.reduce((n,b) => n + Number(b.bidAmount || 0), 0);
      await saveState(state);
      const email = await sendBidEmail(bid, state);
      return response(201, { ...state, emailSent: email.sent });
    }

    if (request.method === 'PATCH') {
      if (!adminOk(request)) return response(401, { error: 'Invalid admin password.' });
      const body = await request.json().catch(() => ({}));
      if (body.action === 'delete') {
        state.bids = state.bids.filter(b => b.timestamp !== body.timestamp);
        state.current = state.bids[0] || null;
        state.raised = state.bids.reduce((n,b) => n + Number(b.bidAmount || 0), 0);
      } else if (body.action === 'select') {
        const b = state.bids.find(x => x.timestamp === body.timestamp);
        if (!b) return response(404, { error: 'Bid not found.' });
        if (body.asNext) {
          state.scheduledNext = b;
        } else {
          state.current = b;
          state.scheduledNext = null;
          state.startAt = body.startAt && !Number.isNaN(Date.parse(body.startAt)) ? new Date(body.startAt).toISOString() : new Date().toISOString();
          state.endAt = body.endAt && !Number.isNaN(Date.parse(body.endAt)) ? new Date(body.endAt).toISOString() : new Date(Date.now()+WINDOW).toISOString();
        }
      } else if (body.action === 'reset') {
        state.bids = [];
        state.current = null;
        state.scheduledNext = null;
        state.raised = 0;
        state.startAt = new Date().toISOString();
        state.endAt = body.endAt && !Number.isNaN(Date.parse(body.endAt)) ? new Date(body.endAt).toISOString() : new Date(Date.now()+WINDOW).toISOString();
      } else {
        return response(400, { error: 'Unknown admin action.' });
      }
      return response(200, await saveState(state));
    }
    return response(405, { error: 'Method not allowed.' });
  } catch (err) {
    console.error(err);
    return response(500, { error: 'Server error. Check Netlify function logs.' });
  }
};
